
package exer01;

import java.util.Scanner;

public class Exer01 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double F,C;
        
        System.out.println("Digite a temperatura em Fahrenheit:");
        F = teclado.nextDouble();
        
        C = (F-32)*5/9;
        System.out.println("A temperatura convertida em Celsius é:"+C);
    }
    
}
