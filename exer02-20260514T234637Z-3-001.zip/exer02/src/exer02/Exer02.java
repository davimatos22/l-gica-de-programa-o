
package exer02;

import java.util.Scanner;

public class Exer02 {
    public static void main(String[] args) {
       Scanner teclado = new Scanner (System.in);
       double C,F;
       
        System.out.println("Digite a temperatura em Celsius");
        C = teclado.nextDouble();
        
        F= C*1.8+32;
        System.out.println("A temperatura convertida em Fahrenheit é:"+F);      
    }
    
}
