
package com.mycompany.exer8comdesvio;

import java.util.Scanner;

public class Exer8comdesvio {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        double n1, n2, n3, media;
       
        System.out.println("informe a primeira nota:");
        n1 = teclado.nextDouble();
        
        System.out.println("informe a segunda nota:");
        n2 = teclado.nextDouble();
        
        System.out.println("informe a terceira nota:");
        n3 = teclado.nextDouble();
        
        media =  n1 + n2 + n3;
        media = media /3;
        
        if (media >= 6){
            System.out.println("aprovado e a média é:"+media);
        } else if (media < 6) {
            System.out.println("reprova e a média é:"+media);
        }
    }
}
