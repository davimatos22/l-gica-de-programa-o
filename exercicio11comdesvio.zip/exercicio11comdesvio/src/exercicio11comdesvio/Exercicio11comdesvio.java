
package exercicio11comdesvio;

import java.util.Scanner;

public class Exercicio11comdesvio {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        double n1, n2, n3, media=0;
        int codigo;
        System.out.println("informe o seu codigo de matricula:");
        codigo = teclado.nextInt();
        System.out.println("digite a primeira nota");
        n1 = teclado.nextDouble();
        System.out.println("digite a segunda nota");
        n2 = teclado.nextDouble();
        System.out.println("digite a terceira nota");
        n3 = teclado.nextDouble();
        
        if (n1 >= n2 && n1 >=n3){
            media = (n1*4 + n2*3 + n3*3)/10;
        }else if (n2 >= n3){
            media = (n2*4 + n1*3 + n3*3)/10;
        }else  {    
            media = (n3*4 + n1*3 + n2*3)/10; 
        }
        
        if (media >= 5){   
            System.out.println("o codigo é "+codigo+" e o aluno está aprovado. A media foi:"+media);
        } else if (media < 5) {
            System.out.println("o codigo do aluno é "+codigo+"e o aluno está reprovado. A media foi:"+media);
        }   
    }
}
