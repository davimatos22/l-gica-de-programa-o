
package exercicio12comdesvio;

import java.util.Scanner;

public class Exercicio12comdesvio {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int n1;
        
        System.out.println("digite o numero");
        n1 = teclado.nextInt();
        
        if ( n1 %2 == 0 && n1 >=0) {
            System.out.println("o numero e positivo e par.");
        }else if ( n1 %2 == 0 && n1 <=0) {
            System.out.println("o numero e negativo e par.");
        }else if (n1 >= 0) {
            System.out.println("o numero e impar e é positivo");
        }else  {
            System.out.println("o numero e impar e negativo");
        }
    }
    
}
