
package exercicio14comdesvio;

import java.util.Scanner;

public class Exercicio14comdesvio {

    
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        double n1, n2, n3, media;
        int tipo;
        
        System.out.println("digite a primeira nota");
        n1 = teclado.nextDouble();
        System.out.println("digite a segunda nota");
        n2 = teclado.nextDouble();
        System.out.println("digite a terceira nota");
        n3 = teclado.nextDouble();
        
        System.out.println("digite o tipo de media para ser calculada(1 para media aritmetica e 2 para ponderada.)");
        tipo = teclado.nextInt();
        
        
        if (tipo == 1){
            media = (n1 + n2 + n3)/3;
        }else {
            media = (n1 *3 + n2 *3 + n3 *4)/10;
        }
        System.out.println("a media é"+media);
    }
    
}
