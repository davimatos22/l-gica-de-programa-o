package exercicio15comdesvio;

import java.util.Scanner;

public class Exercicio15comdesvio {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double saldom, credito;

        System.out.print("Informe o saldo medio do ultimo ano: ");
        saldom = teclado.nextDouble();

        if (saldom <= 200) {
            credito = 0;
        } else if (saldom <= 400) {
            credito = saldom * 0.2;
        } else if (saldom <= 600) {
            credito = saldom * 0.3;
        } else if (saldom > 600) {
            credito = saldom * 0.4;
        }

        System.out.println("Saldo medio: " + saldom);
        System.out.println("Credito: " + credito);
    }
}

