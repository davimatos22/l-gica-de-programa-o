
package exercicio16comdesvio;

import java.util.Scanner;

public class Exercicio16comdesvio {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
 
        int precot, produto, quantidade;
        
        
        System.out.println("insira o codigo do produto:");
        produto = teclado.nextInt();
        System.out.println("informe a quantidade do produto:");
        quantidade = teclado.nextInt();
        
        
        if (produto == 5){
            precot = quantidade *32;
            System.out.println("o preço total e de "+precot);
        } else if (produto == 6){
            precot = quantidade *45;
            System.out.println("o preço total e de "+precot);
        } else if (produto == 2){
            precot = quantidade *37;
        System.out.println("o preço total e de "+precot);
        } else if (produto == 12){
            precot = quantidade *37;
            System.out.println("o preço total e de "+precot);
        } else {
            System.out.println("Código de produto inválido!");
        }
    }
    
}
