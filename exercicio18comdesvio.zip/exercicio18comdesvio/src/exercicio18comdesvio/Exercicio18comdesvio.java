
package exercicio18comdesvio;

import java.util.Scanner;

public class Exercicio18comdesvio {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int codigo;
        double salario, salarion;
        
        System.out.println("informe o codigo do cargo:");
        codigo = teclado.nextInt();
        System.out.println("informe o salario atual:");
        salario = teclado.nextDouble();
        
        if (codigo == 101){
            salarion = salario *0.1 + salario;
            System.out.println("o novo salario é "+salarion);
        }else if (codigo == 102){
            salarion = salario *0.2 + salario;
            System.out.println("o novo salario é "+salarion);
        }else if (codigo == 103){
            salarion = salario *0.3 + salario;
            System.out.println("o novo salario é "+salarion);
        }else {
            salarion = salario *0.4 + salario;
            System.out.println("o novo salario é "+salarion);
        }
    }
    
}
