
package exercicio19comdesvio;

import java.util.Scanner;

public class Exercicio19comdesvio {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double a, b, c, area, s;    
        
        System.out.println("informe o valor de a:");
        a = teclado.nextDouble();
        System.out.println("informe o valor de b");
        b = teclado.nextDouble();
        System.out.println("informe o valor de c");
        c = teclado.nextDouble();
        
        if (a + b >= c && a + c >= b && b + c >= a ){
            s = (a + b + c)/2.0;
            area = Math.sqrt(s*(s - a)*(s - b)*(s - c));
            System.out.println("a area do triangulo e: "+area);
        } else {
            System.out.println("nao e possivel fazer um triangulo com os valores");
        }
                              
        
    }
    
}
