
package exercicio1comdesvio;

import java.util.Scanner;

public class Exercicio1comdesvio {


    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        
        int num;
        
        System.out.println("informe o número desejado:");
        num = teclado.nextInt();
        
        if (num %2 ==0) {
            System.out.println("seu número é par.");
            
        } else {
            System.out.println("seu número é ímpar.");
        }
         
        
    }
    
}
