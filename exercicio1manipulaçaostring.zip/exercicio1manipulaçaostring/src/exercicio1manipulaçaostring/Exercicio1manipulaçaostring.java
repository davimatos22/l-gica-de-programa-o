
package exercicio1manipulaçaostring;

import java.util.Scanner;

public class Exercicio1manipulaçaostring {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String pouf;
        int tamanho;
        
        System.out.println("informe uma palavra ou frase: ");
        pouf = teclado.nextLine();
        
        tamanho = pouf.length();
        System.out.println("o numero de caracteres do que foi digitado é: "+tamanho);
        
    }
    
}
