
package exercicio1matriz;

import java.util.Scanner;

public class Exercicio1matriz {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        
        String matriznome [][]= new String [5][5];
        
        
        for (int linha = 0; linha < 5; linha++) {
            
            for (int coluna = 0; coluna < 5; coluna++) {
                System.out.println("escreva um nome para preencher a tabela");
                matriznome [linha][coluna] = teclado.nextLine();
            }
        }
        
        for (int linha = 0; linha < 5; linha++) {
            for (int coluna = 0; coluna < 5; coluna++) {
                System.out.println(matriznome [linha][coluna]);
            }
            
        }
        
    }
    
}
