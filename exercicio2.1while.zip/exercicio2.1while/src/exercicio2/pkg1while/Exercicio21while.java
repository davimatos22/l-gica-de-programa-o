
package exercicio2.pkg1while;

import java.util.Scanner;

public class Exercicio21while {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
          int num = 2, numinformado, cont = 1;
          
          System.out.println("informe o numero na sequencia");
          numinformado = teclado.nextInt();
          
          
          while (cont <= numinformado){
              System.out.println(num);
              num = num * 2;
              cont++;
          }
         
    }
    
}
