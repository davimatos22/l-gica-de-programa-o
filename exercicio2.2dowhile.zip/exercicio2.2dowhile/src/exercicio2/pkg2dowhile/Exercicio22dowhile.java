
package exercicio2.pkg2dowhile;


import java.util.Scanner;

public class Exercicio22dowhile {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
         int num = 2, numinformado, cont = 1;
          
         System.out.println("informe o numero na sequencia");
         numinformado = teclado.nextInt();
         do { 
             System.out.println(num);
             num = num * 2;
             cont++;
         }
          
         while (cont <= numinformado);
             
    }
    
}
