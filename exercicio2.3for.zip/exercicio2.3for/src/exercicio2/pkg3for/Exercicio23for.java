
package exercicio2.pkg3for;

import java.util.Scanner;

public class Exercicio23for {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int numinformado, num = 2;
        System.out.println("informe o numero");
        numinformado = teclado.nextInt();
         for (int i = 0; i < numinformado; i++){
             System.out.println(num);
             num = num*2;
             
         }
             
    }
    
}
