
package exercicio20comdesvio;

import java.util.Scanner;

public class Exercicio20comdesvio {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int dinheiro, rest, cem, cinquenta, dez, cinco, um;
        
        System.out.println("informe a quantia de dinheiro:");
        dinheiro = teclado.nextInt();
        
        cem = dinheiro /100;
        rest = dinheiro - 100*cem;
        cinquenta = rest /50;
        rest = rest - 50*cinquenta;
        dez = rest /10;
        rest = rest - 10*dez;
        cinco = rest /5;
        rest = rest - 5*cinco;
        
        um = rest;
        
        System.out.println("notas de 100: "+cem);
        System.out.println("notas de 50: "+cinquenta);
        System.out.println("notas de 10: "+dez);
        System.out.println("notas de 5: "+cinco);
        System.out.println("notas de 1: "+um);
        
    }
    
}
