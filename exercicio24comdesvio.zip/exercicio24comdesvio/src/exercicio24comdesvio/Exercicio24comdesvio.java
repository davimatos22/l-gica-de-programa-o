
package exercicio24comdesvio;

import java.util.Scanner;

public class Exercicio24comdesvio {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int quantidade;
        double valor;
        
        System.out.println("informe a quantidade de maças que deseja:");
        quantidade = teclado.nextInt();
        
        if (quantidade < 12){
            valor = quantidade *1.3;
            System.out.println("o preço a pagar é: "+valor);
        } else {
            valor = quantidade *1;
            System.out.println("o preço a pagar é: "+valor);
        }
    }
    
}
