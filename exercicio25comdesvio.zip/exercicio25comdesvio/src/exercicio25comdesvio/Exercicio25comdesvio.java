
package exercicio25comdesvio;

import java.util.Scanner;

public class Exercicio25comdesvio {
    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       int gols1, gols2;
       String nome1, nome2;
       
       System.out.println("informe o nome do time 1");
       nome1 = teclado.nextLine();
       
       System.out.println("informe a quantidade de gols do "+nome1);
       gols1 = teclado.nextInt();
       teclado.nextLine();
       System.out.println("informe o nome do time 2");
       nome2 = teclado.nextLine();
       
       System.out.println("informe a quantidade de gols do "+nome2);
       gols2 = teclado.nextInt();
       
       if (gols1 > gols2){
           System.out.println("o time "+nome1+" e o ganhador");
       }else if (gols2 > gols1) {
           System.out.println("o time "+nome2+" e o ganhador");
       }else {
           System.out.println("deu empate.");
       }
    }
    
}
