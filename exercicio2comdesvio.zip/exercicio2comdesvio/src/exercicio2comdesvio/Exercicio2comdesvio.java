
package exercicio2comdesvio;

import java.util.Scanner;

public class Exercicio2comdesvio {


    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int num;
        
        System.out.println("informe um número:");
        num = teclado.nextInt();
        
        if (num %2 == 0 && num %3 == 0){
            System.out.println("seu número é divisivel por 2 e 3.");
        
        } else { 
            System.out.println("seu número não é divisivel por 2 e 3.");
         }
    }
}
