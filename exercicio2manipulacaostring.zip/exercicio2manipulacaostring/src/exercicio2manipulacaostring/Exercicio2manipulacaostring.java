
package exercicio2manipulacaostring;

import java.util.Scanner;

public class Exercicio2manipulacaostring {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        String frase;
        int qtdvogal = 0;
        
        System.out.println("informe uma frase: ");
        frase = teclado.nextLine();
        
        
        
        for (int i = 0; i < frase.length(); i++) {
            if (frase.charAt(i) == 'a' || frase.charAt(i) == 'e' || frase.charAt(i) == 'i' || frase.charAt(i) == 'o' || frase.charAt(i) == 'u' || frase.charAt(i) == 'A' || frase.charAt(i) == 'E' || frase.charAt(i) == 'I' || frase.charAt(i) == 'O' || frase.charAt(i) == 'U' || frase.charAt(i) == 'á' || frase.charAt(i) == 'é' || frase.charAt(i) == 'í' || frase.charAt(i) == 'ó' || frase.charAt(i) == 'ú' || frase.charAt(i) == 'Á' || frase.charAt(i) == 'É' || frase.charAt(i) == 'Í' || frase.charAt(i) == 'Ó' || frase.charAt(i) == 'Ú') {
                qtdvogal = qtdvogal + 1;
                
            }  
            
         } System.out.println("o numero de vogais é: "+qtdvogal);
    } 
    
}
