
package exercicio2matriz;

import java.util.Scanner;

public class Exercicio2matriz {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        
        int matriznum [][] = new int [3][3];
        int menor;
        
        for (int linha = 0; linha < 3; linha++) {
            for (int coluna = 0; coluna < 3; coluna++) {
                System.out.println("informe o valor do numero");
                matriznum [linha][coluna] = teclado.nextInt();
            }
        }
        menor = matriznum [0][0];
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (matriznum [i][j] < menor){
                        menor = matriznum [i][j];
                        
                }
               }     
            }
            System.out.println("o valor menor é: "+menor);

                
            }
        }
    
    

