
package exercicio2vetores;

import java.util.Scanner;

public class Exercicio2vetores {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int vetnum [] = new int [11];
        
        for (int i = 1; i < 11; i++) {
            System.out.println("informe o "+i+" numero: ");
            vetnum [i] = teclado.nextInt();
                
                
        }
        System.out.println("A listagem dos numeros superiores a 50 é: ");
        for (int i = 1; i < 11; i++) {
                if(vetnum[i] > 50){
                    
                    System.out.println(vetnum[i]);
                }
        }
        
    }
    
}
