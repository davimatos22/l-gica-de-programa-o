
package exercicio3.pkg3for;

import java.util.Scanner;

public class Exercicio33for {

 
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int pessoas, voto, aaa = 0, bbb = 0, ccc = 0, nulo = 0;
        
        System.out.println("quantas pessoas vao votar:");
        pessoas = teclado.nextInt();
        
        for (int i = 0; i < pessoas; i++) {
             System.out.println("informe o seu candidato: 1-aaa, 2-bbb, 3-ccc, 4-nulo.");
             voto = teclado.nextInt();
             
             if (voto == 1){
                 aaa = aaa + 1;
             } else if (voto == 2){
                 bbb = bbb + 1;
             } else if (voto == 3){
                 ccc = ccc + 1;
             } else if (voto == 4) { 
                 nulo = nulo + 1;
             }
        } System.out.println("o numero de votos é: aaa = "+aaa+ " bbb = "+bbb+ " ccc = "+ccc+" nulo= "+nulo );  
        
        
    }
    
}
