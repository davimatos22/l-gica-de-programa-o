
package exercicio3;

import java.util.Scanner;

public class Exercicio3 {


    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        double rai,alt,vol;
        
        System.out.println("informe a altura");
        alt = teclado.nextDouble();
        System.out.println("informe o raio");
        rai = teclado.nextDouble();
        
        vol = 3.14159 * rai * rai * alt;
        System.out.println("o volume é:" +vol);
    }
    
}
