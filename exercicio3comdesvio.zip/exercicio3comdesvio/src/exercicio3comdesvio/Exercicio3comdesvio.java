package exercicio3comdesvio;

import java.util.Scanner;

public class Exercicio3comdesvio {


    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int num;
        
        System.out.println("informe um número:");
        num = teclado.nextInt();
        
        if (num %5 == 0 || num %7 == 0){
            System.out.println("seu número é divisivel por 5 ou 7.");
        
        } else { 
            System.out.println("seu número não é divisivel por 5 ou 7.");
         }
    }
}
