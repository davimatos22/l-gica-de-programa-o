
package exercicio3vetores;

import java.util.Scanner;

public class Exercicio3vetores {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int vetnum [] = new int [10];
        
        for (int i = 1; i < 10; i++) {
            System.out.println("informe o numero "+i+":");
            vetnum[i] = teclado.nextInt();
            
        }
        
        System.out.println("os numeros primos são: ");
        for (int i = 1; i < 10; i++) {
            if(vetnum[i] / 1 == 0 && vetnum[i] / vetnum[i] == 0){
                System.out.println(vetnum[i]);
            }
        }
    }
    
}
