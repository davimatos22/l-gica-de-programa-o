
package exercicio4;

import java.util.Scanner;

public class Exercicio4 {

 
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int n1,n2,temp;
        
        System.out.println("informe o primeiro número:");
        n1 = teclado.nextInt();
        System.out.println("informe o segundo número:");
        n2 = teclado.nextInt();
        temp = n1;
        
        n1 = n2;
        n1 = temp;
        
        System.out.println("invertendo os valores, a variavel 1 recebeu o valor:"+n2+"e a variavel 2 recebeu o valor de:"+n1);
        
    }
    
}
