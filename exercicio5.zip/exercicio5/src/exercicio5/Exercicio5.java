
package exercicio5;

import java.util.Scanner;

public class Exercicio5 {


    public static void main(String[] args) {
       Scanner teclado = new Scanner (System.in);
       double comp,alt,lar,vol;
       
        System.out.println("informe o comprimento:");
        comp = teclado.nextDouble();
        System.out.println("informe a altura:");
        alt = teclado.nextDouble();
        System.out.println("informe a largura:");
        lar = teclado.nextDouble();
        
        vol = comp * alt * lar;
        System.out.println("o volume é:"+vol);
        
       
    }
    
}
