package exvt07_funcionarios;

import java.util.Scanner;

public class Exvt07_funcionarios {

    public static void main(String[] args) {
        
        Scanner vero = new Scanner(System.in);
        String nomedofuncionario[] = new String[5];
        double salariodofuncionario[] = new double[5];
        int tempodetrabalho[] = new int[5], rep = 0, aumento;
        
        System.out.println("informe os dados dos funcionarios");
        System.out.println("");
        for (int i = 0; i < 5; i++) {
            vero.nextLine();
            System.out.println("funcionario " + (i + 1));
            System.out.print("nome: ");
            nomedofuncionario[i] = vero.nextLine();
            System.out.print("salario: ");
            salariodofuncionario[i] = vero.nextDouble();
            System.out.print("anos de servico: ");
            tempodetrabalho[i] = vero.nextInt();            
        }
        while(rep <= 1)
            if (rep == 0) {
                System.out.println("funcionarios que nao tiveram aumento:");
            } else {
                System.out.println("funcionarios que tiveram aumento e seus respectivos salarios:");
            }
        
            for (int i = 0; i < 5; i++) {
                aumento = 0;
                if (tempodetrabalho[i] > 5 && salariodofuncionario[i] < 1940) {
                    salariodofuncionario[i] = salariodofuncionario[i] * 1.35;
                    aumento = 1;
                    if (rep == 1) {
                        System.out.println(nomedofuncionario[i] + ": " + salariodofuncionario[i] + "R$");
                    }
                } else if (tempodetrabalho[i] > 5) {
                    salariodofuncionario[i] = salariodofuncionario[i] * 1.25;
                    aumento = 1;
                    if (rep == 1) {
                        System.out.println(nomedofuncionario[i] + ": " + salariodofuncionario[i] + "R$");
                } else if (salariodofuncionario[i] < 1940) {
                    salariodofuncionario[i] = salariodofuncionario[i] * 1.15;
                    aumento = 1;
                    if (rep == 1) {
                        System.out.println(nomedofuncionario[i] + ": " + salariodofuncionario[i] + "R$");
                    }
                } else if (aumento == 0 && rep == 0) {
                        System.out.println(nomedofuncionario[i]);    
                }
            }
        }
        
    }
    
}
