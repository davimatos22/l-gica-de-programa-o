
package exercicio1dowhile;

import java.util.Scanner;

public class Exercicio1dowhile {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int senha = 9999, senhainformada;
                
        do {
            System.out.println("digite a senha:");
            senhainformada = teclado.nextInt();
          } while(senhainformada != senha);
          System.out.println("A senha está correta.");
        
    }
    
}
