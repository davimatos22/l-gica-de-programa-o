
package exercicio2dowhile;

import java.util.Scanner;

public class Exercicio2dowhile {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        double num, vezes = 0, acumulador = 0, media;
        
        do {
            System.out.println("Digite um número:");
            num = teclado.nextDouble();
            acumulador += num;
            vezes++;
        }while (num != 0);
        media = acumulador/(vezes - 1);
        
        System.out.println("A soma dos números é: "+acumulador);
        System.out.println("A quantidade de números é "+(vezes - 1));
        System.out.println("A média é: "+media);
            
    }
    
}
