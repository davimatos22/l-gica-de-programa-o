
package exercicio3m;
import java.util.Scanner;

public class Exercicio3m {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Digite uma frase: ");
        String frase = teclado.nextLine();

        int palavras = 0;
        char anterior = ' ';

        for (int i = 0; i < frase.length(); i++) {
            char atual = frase.charAt(i);

            
            if (atual != ' ' && anterior == ' ') {
                palavras++;
            }

            anterior = atual;
        }

        System.out.println("Quantidade de palavras: " + palavras);

       
    }
}