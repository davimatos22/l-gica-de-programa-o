
package exercicio5m;

import java.util.Scanner;

public class Exercicio5m {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Digite uma data (dd/mm/aaaa ou dd/mm/aa): ");
        String data = teclado.nextLine();

       
        String partes[] = data.split("/");
        String ano = partes[2];

        int proximoAno = Integer.parseInt(ano) + 1;

       
        if (ano.length() == 2) {
            proximoAno = proximoAno % 100;
        }

        String resposta = Integer.toString(proximoAno);

        
        if (ano.length() == 2 && proximoAno < 10) {
            resposta = "0" + resposta;
        }

        System.out.println("Ano seguinte: " + resposta);

        
    }
}
