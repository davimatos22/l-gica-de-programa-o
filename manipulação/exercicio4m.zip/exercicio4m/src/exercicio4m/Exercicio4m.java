
package exercicio4m;

import java.util.Scanner;

public class Exercicio4m {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Digite o nome completo: ");
        String nome = teclado.nextLine();

       
        int espaco = nome.indexOf(' ');

        String primeiroNome;
        if (espaco == -1) {
            primeiroNome = nome;
        } else {
            primeiroNome = nome.substring(0, espaco);
        }

        System.out.println("Primeiro nome: " + primeiroNome);

        
    }
}