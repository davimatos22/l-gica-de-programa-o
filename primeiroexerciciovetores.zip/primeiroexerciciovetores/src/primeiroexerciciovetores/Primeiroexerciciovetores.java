
package primeiroexerciciovetores;

import java.util.Scanner;

public class Primeiroexerciciovetores {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        int tamanho = 5;
        String nomes[] = new String[tamanho];
        
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Digite o " + (i+1) + "° nome:");
            nomes[i] = teclado.nextLine();
            
        }
        
        System.out.println("Lista dos nomes:");
        
        for (int i = 0; i < tamanho; i++) {
            System.out.println("--------------");
            System.out.println(nomes[i]);
        }
    }
    
}
