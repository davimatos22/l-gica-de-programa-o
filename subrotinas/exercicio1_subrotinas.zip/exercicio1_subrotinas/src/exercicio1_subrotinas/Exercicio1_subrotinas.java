
package exercicio1_subrotinas;

import java.util.Scanner;

public class Exercicio1_subrotinas {
    static double multiplicacao (double a, double b){
        double soma = 0;
        soma = a * b;
        return soma;
    }
 
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double n1, n2, soma;
        
        System.out.println("informe os dois numeros: ");
        n1 = teclado.nextDouble();
        n2 = teclado.nextDouble();
        soma = multiplicacao(n1,n2);
        
        System.out.println("o resultado é: "+soma);
    }
    
}
