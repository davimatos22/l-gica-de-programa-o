
package exercicio1_listacomrecursividade;

 
public class Exercicio1_listacomrecursividade {

   public static void subrotina(int a){
       if (a > 100){
           return;
       }
       System.out.println(a);
       subrotina (a + 1);
      
       
   }
    public static void main(String[] args) {
        
        
        subrotina(0);
    }
    
}
