package exercicio2listacomrecursividade;

public class Exercicio2listacomrecursividade {

    public static boolean palindromo(String palavra, int inicio, int fim) {

        if (inicio >= fim) {
            return true;
        }

        if (palavra.charAt(inicio) != palavra.charAt(fim)) {
            return false;
        }

        return palindromo(palavra, inicio + 1, fim - 1);
    }

    public static void main(String[] args) {

        String palavra = "radar";

        if (palindromo(palavra, 0, palavra.length() - 1)) {
            System.out.println("É um palíndromo!");
        } else {
            System.out.println("Não é um palíndromo!");
        }
    }
}