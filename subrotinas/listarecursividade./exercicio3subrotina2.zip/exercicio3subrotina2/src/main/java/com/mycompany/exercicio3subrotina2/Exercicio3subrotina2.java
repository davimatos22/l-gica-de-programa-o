
package com.mycompany.exercicio3subrotina2;

import java.util.Scanner;

public class Exercicio3subrotina2 {

    static int subrotina (int vetor[]){
        int maior = vetor[0];
        for (int i = 1; i < vetor.length; i++) {
            if (vetor[i] > maior)
                maior = vetor[i];
            
        }
        
        return maior;
    }
    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int []vetor = new int[3];
        
        
        for (int i = 0; i < vetor.length; i++) {
            
            System.out.println("informe o valor:");  
            vetor[i] = teclado.nextInt();
            
            
        }
        
        System.out.println(subrotina(vetor));
    }
}
