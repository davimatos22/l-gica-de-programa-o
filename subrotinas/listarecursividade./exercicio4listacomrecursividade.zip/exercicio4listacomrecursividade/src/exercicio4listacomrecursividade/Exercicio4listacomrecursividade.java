
package exercicio4listacomrecursividade;
import java.util.Scanner;
public class Exercicio4listacomrecursividade {
    public static double subrotina(double vetor[]){
        double media = 0;
        for (int i = 0; i < vetor.length; i++) {
           media = media + vetor[i];
        }
        media = media / vetor.length;
        return media;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double []vetor = new double[3];
        
        for (int i = 0; i < vetor.length; i++) {
            System.out.println("informe o valor:");
            vetor[i] = teclado.nextDouble();                  
            System.out.println(subrotina(vetor));
        }
    }
    
}
