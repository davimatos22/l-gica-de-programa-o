
package exercicio5listacomrecursividade;

import java.util.Scanner;

public class Exercicio5listacomrecursividade {

    public static boolean subrotina(double vetor[], double numero) {

        for (int i = 0; i < vetor.length; i++) {
            if (vetor[i] == numero) {
                return true;
            }
        }

        return false;
    }

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        double numero;
        double[] vetor = new double[5];

        System.out.println("Informe o numero que deseja procurar:");
        numero = teclado.nextDouble();

        for (int i = 0; i < vetor.length; i++) {
            System.out.println("Informe um numero:");
            vetor[i] = teclado.nextDouble();
        }

        if (subrotina(vetor, numero) == true) {
            System.out.println("O numero está presente!");
        } else if (subrotina(vetor, numero) == false) {
            System.out.println("O numero não está presente!");
        }

        
    }
}
