
package exercicio6listacomrecursividade;

import java.util.Scanner;

public class Exercicio6listacomrecursividade {

    public static int[] subrotina(int vetor1[]) {

        int[] vetor2 = new int[vetor1.length];

        int cont = 1;

        for (int i = 0; i < vetor1.length; i++) {
            vetor2[i] = vetor1[vetor1.length - cont];
            cont++;
        }

        return vetor2;
    }

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        int[] vetor1 = new int[5];

        for (int i = 0; i < vetor1.length; i++) {
            System.out.println("Informe o numero:");
            vetor1[i] = teclado.nextInt();
        }

        int[] vetor2 = subrotina(vetor1);

        for (int i = 0; i < vetor2.length; i++) {
            System.out.println(vetor2[i]);
        }

        teclado.close();
    }
}
