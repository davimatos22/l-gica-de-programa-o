
    
package exercicio7listacomrecursividade;

import java.util.Scanner;

public class Exercicio7listacomrecursividade {

    public static int[] subrotina(int vetor1[]) {

        int[] vetor2 = new int[vetor1.length];
        int cont = 0;

        for (int i = 0; i < vetor1.length; i++) {

            boolean existe = false;

            for (int j = 0; j < cont; j++) {

                if (vetor1[i] == vetor2[j]) {
                    existe = true;
                    break;
                }

            }

            if (!existe) {
                vetor2[cont] = vetor1[i];
                cont++;
            }
        }

        int[] resultado = new int[cont];

        for (int i = 0; i < cont; i++) {
            resultado[i] = vetor2[i];
        }

        return resultado;
    }

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        int[] vetor1 = new int[5];

        for (int i = 0; i < vetor1.length; i++) {
            System.out.println("Informe um numero:");
            vetor1[i] = teclado.nextInt();
        }

        int[] resultado = subrotina(vetor1);

        System.out.println("Vetor sem duplicados:");

        for (int i = 0; i < resultado.length; i++) {
            System.out.println(resultado[i]);
        }

        
    }
}
