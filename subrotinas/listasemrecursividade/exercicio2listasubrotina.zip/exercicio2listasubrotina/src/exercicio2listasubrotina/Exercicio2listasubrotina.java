package exercicio2listasubrotina;

import java.util.Scanner;

public class Exercicio2listasubrotina {

    static int soma(int a, int b) {
        int resp = a;

        for (int i = a; i <= b; i++) {
            resp = resp + i;
        }
        return resp;
    }

    static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int N1, N2, result;

        System.out.println("Digite dois numeros inteiros");
        N1 = teclado.nextInt();
        N2 = teclado.nextInt();

        result = soma(N1, N2);
        System.out.println(result);
    }

}
