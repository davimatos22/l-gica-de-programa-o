
package exercicio4listasubrotina;

import java.util.Scanner;

public class Exercicio4listasubrotina {
    
    static String triangulo (int lado1, int lado2, int lado3){
        
        if (lado1 <= 0 || lado2 <= 0 || lado3 <= 0) {
            return "Nao eh um triangulo";            
        } else if (lado1 > lado2+ lado3) {
            return "Nao eh um triangulo";
        }else if (lado2 > lado1 + lado3) {
            return "Nao eh um triangulo";
        }else if (lado3 > lado1 + lado2) {
            return "Nao eh um triangulo";
        }
        
        if (lado1 == lado2 && lado2 == lado3) {
            return "Equilatero";
        }else if (lado1 == lado2 || lado2 == lado3 || lado1 == lado3) {
            return "Isosceles";
        }else {
        return "Escaleno";
        }
    }
    

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int ladoA, ladoB, ladoC;
        
        System.out.println("Digite 3 valores para os lados do triangulo");
        ladoA = teclado.nextInt();
        ladoB = teclado.nextInt();
        ladoC = teclado.nextInt();
        
        System.out.println(triangulo(ladoA, ladoB, ladoC));
    }
    
}
