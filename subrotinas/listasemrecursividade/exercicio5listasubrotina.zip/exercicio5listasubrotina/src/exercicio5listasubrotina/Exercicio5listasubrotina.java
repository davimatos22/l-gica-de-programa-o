
package exercicio5listasubrotina;

import java.util.Scanner;
public class Exercicio5listasubrotina {
   
    static double notas(double N1, double N2, double N3, double media, char letra){
    
        if (letra == 'A') {
            media = (N1 + N2 + N3) / 3;
        } else if (letra == 'P') {
            media = ((N1 * 5) + (N2 * 3) + (N3 * 2)) / (5 + 3 + 2);
        }
        return media;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double n1, n2, n3, media = 0;
        char letter;
        
        System.out.println("Digite as 3 notas do aluno");
        n1 = teclado.nextDouble();
        n2 = teclado.nextDouble();
        n3 = teclado.nextDouble();
        
        System.out.println("Digite 'A' para calcular a media aritimetica ou"
                + " 'P' para calcular a media ponderada");
        letter = teclado.next().charAt(0);
        
        System.out.println(notas(n1, n2, n3, media,letter));
    }
    
}