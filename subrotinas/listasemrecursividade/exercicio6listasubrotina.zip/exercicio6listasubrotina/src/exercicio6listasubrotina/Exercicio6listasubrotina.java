
package exercicio6listasubrotina;
import java.util.Scanner;

public class Exercicio6listasubrotina {
   
    static int jogo(int iniH, int iniMin, int ini_tudo, int fimH, int fimMin, int fim_tudo, int total){
        ini_tudo = iniH * 60 + iniMin;
        fim_tudo = fimH * 60 + fimMin;
        total = fim_tudo - ini_tudo;
        
        if (fim_tudo < ini_tudo) {
            total = 1440 - ini_tudo + fim_tudo;            
        }
        if (total > 1440) {
            System.out.println("O tempo de jogo nao eh valido");            
        }
        return total;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int ini_hr, ini_min, fim_hr, fim_min;
        int ini_soma = 0, fim_soma = 0, result = 0;
        System.out.println("Que horas começou o jogo?");
        ini_hr = teclado.nextInt();
        System.out.println("Em qual minuto começou o jogo?");
        ini_min = teclado.nextInt();
        System.out.println("Que hrs terminou o jogo?");
        fim_hr = teclado.nextInt();
        System.out.println("Em qual minuto terminou o jogo?");
        fim_min = teclado.nextInt();
        
        System.out.println("O tempo total de jogo em minutos foi de: " +jogo(ini_hr, ini_min, ini_soma, fim_hr, fim_min, fim_soma, result));
    }
    
}