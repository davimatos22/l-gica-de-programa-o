
package exercicio7listasubrotina;
import java.util.Scanner;
public class Exercicio7listasubrotina {
   
    static boolean primo(int numero){
        int divisores = 0;
        
        if (numero <= 1) {
            return false;
        }
    
        for (int i = 1; i <= numero; i++) {
            if (numero % i == 0) {
                divisores++;                
            }
        }
        if (divisores <= 2) {
            return true;            
        } else{
        return false;
        }
    }
    

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int Num = 0;
        
        System.out.println("Digite um numero");
        Num = teclado.nextInt();
        
        System.out.println(primo(Num));
    }
    
}
