package exercicio8istasubrotina;

import java.util.Scanner;

public class Exercicio8istasubrotina {

    static void comparaçao(int n1, int n2, int n3, int n4, int n5) {
        int[] numeros = {n1, n2, n3, n4, n5};
        int maior = numeros[0];
        int menor = numeros[0];

        for (int i = 1; i < 5; i++) {
            if (numeros[i] > maior) {
                maior = numeros[i];
            }
            if (numeros[i] < menor) {
                menor = numeros[i];
            }
        }
        System.out.println("Maior numero: " + maior);
        System.out.println("Menor numero: " + menor);
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int N1, N2, N3, N4, N5;

        System.out.println("Digite 5 numeros inteiros");
        N1 = teclado.nextInt();
        N2 = teclado.nextInt();
        N3 = teclado.nextInt();
        N4 = teclado.nextInt();
        N5 = teclado.nextInt();

        comparaçao(N1, N2, N3, N4, N5);
    }

}
