
package exercicio9listasubrotina;
import java.util.Scanner;
public class Exercicio9listasubrotina {
   
     public static String abreviarNome(String nome) {

        String[] partes = nome.trim().split("\\s+");

        String resultado = partes[0];

        for (int i = 1; i < partes.length - 1; i++) {
            resultado += " " + partes[i].charAt(0) + ".";
        }

        if (partes.length > 1) {
            resultado += " " + partes[partes.length - 1];
        }

        return resultado;
    }

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String nome, nomeAbrev;
        
        System.out.println("Digite o nome completo");
        nome = teclado.nextLine();
        
        nomeAbrev = abreviarNome(nome);
        
        System.out.println("Nome abreviado: " +nomeAbrev);
        
    }
    
}

