
package exercicio4vetores;

import java.util.Scanner;

public class Exercicio4vetores {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        String vetanimais [] = new String [5];
        String vetfrutas [] = new String [5];
        String vetmesclado [] = new String [10];
       
        for (int i = 0; i < 5; i++) {
            System.out.println("informe o nome do animais que deseja: ");
            vetanimais[i] = teclado.nextLine();
            
        }
        
        for (int i = 0; i < 5; i++) {
            System.out.println("informe o nome das frutas que deseja: ");
            vetfrutas[i] = teclado.nextLine();
                 
        }
        
        for (int i = 0; i < 5; i++) {
            vetmesclado[i * 2] = vetanimais[i];
            vetmesclado[i * 2 + 1] = vetfrutas[i];
        }   
        
        for (int i = 0; i < 10; i++) {
            System.out.println(vetmesclado[i]);
            
        }
    }
}
